import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { UserService } from "./user/user.service";

@Component({
    selector: 'app-header',
    template: `
    <header class="row">
    <nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#"><b>Bill Payment</b></a>
      </div>

        
       <ul class="nav nav-pills ">
        <li class="active" *ngIf="isLoggedIn()"><a href="#home">Home</a></li>
        <li class="dropdown" *ngIf="isLoggedIn()">
            <a class="dropdown-toggle" data-toggle="dropdown">Bills
            <span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li routerLinkActive="active" *ngIf="isAdmin()"><a [routerLink]="['/bills/allbills']">View</a></li>
                <li routerLinkActive="active" *ngIf="isUser()"><a [routerLink]="['/bills/allbills',{userId:userId}]">View</a></li>
                <li routerLinkActive="active" *ngIf="isUser()"><a [routerLink]="['/bills/viewbillhistory']">PaymentHistory</a></li>
                <li routerLinkActive="active" *ngIf="isAdmin()"><a [routerLink]="['/bills/addbill']">Generate</a></li>
                        
            </ul>
        </li>
        <li class="dropdown" *ngIf="isAdmin()">
            <a class="dropdown-toggle" data-toggle="dropdown">Billers
            <span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li routerLinkActive="active"><a [routerLink]="['/billers/allbillers']">View</a></li>
                <li routerLinkActive="active"><a [routerLink]="['/billers/addbiller']">Create</a></li>    
            </ul>
        </li>
        <li routerLinkActive="active" *ngIf="isLoggedIn() && isAdmin()"><a [routerLink]="['/billers/chart']"> Chart</a></li>
        <ul class="nav navbar-nav navbar-right">
        <li routerLinkActive="active" *ngIf="!isLoggedIn()"><a [routerLink]="['/auth/signup']"><span class="glyphicon glyphicon-user"></span>    Sign up</a></li>
        
        <li routerLinkActive="active" *ngIf="!isLoggedIn()"><a [routerLink]="['/auth/signin']"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
        <li routerLinkActive="active" *ngIf="isLoggedIn() && isAdmin()">Welcome Admin </li>
        <li routerLinkActive="active" *ngIf="isLoggedIn() && isUser()">Welcome User </li>
        <button class="btn navbar-btn" (click)="onLogout()" *ngIf="isLoggedIn()">Logout</button>
      </ul>
      </ul>
      
      <div class="tab-content">
        <div id="home" class="tab-pane fade in active"*ngIf="isAdmin()" >
          <h3>Welcome BillPayment System</h3>
          <p>This system helps you to do create, edit and delete bills and billers. It shows chart for top bill payments done by users.</p>
        </div>
        <div id="home" class="tab-pane fade in active"*ngIf="isUser()" >
            <h3>Welcome BillPayment System</h3>
            <p>This system helps you to make payment and view payments history</p>
        </div>
      </div>
    
    

      <!--<ul class="nav navbar-nav">
        <li routerLinkActive="active" *ngIf="isAdmin()"><a [routerLink]="['/bills/allbills']">Bills <span class="glyphicon glyphicon-th-list"></span></a></li>
        <li routerLinkActive="active" *ngIf="isUser()"><a [routerLink]="['/bills/allbills',{userId:userId}]">Bills <span class="glyphicon glyphicon-th-list"></span></a></li>
        <li routerLinkActive="active" *ngIf="isAdmin()"><a [routerLink]="['/bills/addbill']">Add Bill</a></li>
        <li routerLinkActive="active" *ngIf="isUser()"><a [routerLink]="['/bills/viewbillhistory']">PaymentHistory <span class="icon-history"></span></a></li>
        <li routerLinkActive="active" *ngIf="isAdmin()"><a [routerLink]="['/billers/allbillers']">Billers <span class="glyphicon glyphicon-th-list"></span></a></li>
        <li routerLinkActive="active" *ngIf="isAdmin()"><a [routerLink]="['/billers/addbiller']">Add Biller</a></li>    
        <li routerLinkActive="active" *ngIf="isLoggedIn() && isAdmin()"><a [routerLink]="['/billers/chart']"> Chart <span class="glyphicon glyphicon-stats"></span></a></li>
      </ul>-->
      
    </div>
  </nav>
    
  <!--<div class="container">
    <h3>Inverted Navbar</h3>
    <p>An inverted navbar is black instead of gray.</p>
  </div>
  
            <nav class="navbar navbar-dark bg-primary">


                <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand">Bill Payment</a>
                </div>
                <ul class="nav navbar-nav">
                    
                <li class="dropdown" routerLinkActive="active" *ngIf="isLoggedIn()"><a class="dropdown-toggle" data-toggle="dropdown">   Bill <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li routerLinkActive="active" *ngIf="isAdmin()"><a [routerLink]="['/bills/allbills']">All Bills</a></li>
                        <li routerLinkActive="active" *ngIf="isUser()"><a [routerLink]="['/bills/allbills',{userId:userId}]">All Bills</a></li>
                        <li routerLinkActive="active" *ngIf="isAdmin()"><a [routerLink]="['/bills/addbill']">Add Bill</a></li>
                        <li routerLinkActive="active" *ngIf="isUser()"><a [routerLink]="['/bills/viewbillhistory']">View Bill Payment History</a></li>
                    </ul></li>
                
                <li class="dropdown" routerLinkActive="active" *ngIf="isLoggedIn() && isAdmin()"><a class="dropdown-toggle" data-toggle="dropdown"> Biller <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a [routerLink]="['/billers/allbillers']">All Billers</a></li>
                    <li><a [routerLink]="['/billers/addbiller']">Add Biller</a></li>    
                </ul></li>

                <li routerLinkActive="active" *ngIf="isLoggedIn() && isAdmin()"><a [routerLink]="['/billers/chart']"> Chart <span class="glyphicon glyphicon-stats"></span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li routerLinkActive="active" *ngIf="!isLoggedIn()"><a [routerLink]="['/auth/signup']"><span class="glyphicon glyphicon-user"></span>    Sign up</a></li>
                    
                    <li routerLinkActive="active" *ngIf="!isLoggedIn()"><a [routerLink]="['/auth/signin']"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                        
                    <button class="btn navbar-btn" (click)="onLogout()" *ngIf="isLoggedIn()">Logout</button>
                    
                </ul>
                </div>  
            </nav>-->
    </header>
    `
})

export class HeaderComponent{
    constructor(private userService: UserService, private router: Router){}

    isLoggedIn(){
        return this.userService.isLoggedIn();
    }

    isAdmin(){
        return this.userService.isAdmin();
    }

    isUser(){
        return this.userService.isUser();
    }

    onLogout(){
        this.userService.logout();
        this.router.navigateByUrl('/auth/signin');
    }
}